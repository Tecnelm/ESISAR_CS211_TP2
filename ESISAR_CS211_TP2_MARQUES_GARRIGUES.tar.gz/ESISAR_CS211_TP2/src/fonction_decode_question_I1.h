
void decodeFonction (char *source_path, char *transporteur_path);
