#include <stdio.h>
#include "utility_fonction.h"
#include <stdlib.h>


void get_nombre_impairs (void);

int *get_info_char (const char *folder_name);

void aff_value (int *table, const char *folder_name);